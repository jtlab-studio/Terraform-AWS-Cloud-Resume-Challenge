import json
import boto3
from botocore.exceptions import ClientError

# DynamoDB setup
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cloudresume') 

def lambda_handler(event, context):
    """
    Increment visitor counter and return current count
    """
    try:
        # Atomically increment the count
        response = table.update_item(
            Key={'id': 'visits'},
            UpdateExpression='ADD #c :inc',
            ExpressionAttributeNames={'#c': 'count'},
            ExpressionAttributeValues={':inc': 1},
            ReturnValues='UPDATED_NEW'
        )
        
        count = int(response['Attributes']['count'])
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'  # CORS for frontend fetch
            },
            'body': json.dumps({'visits': count})
        }
        
    except ClientError as e:
        print(e.response['Error']['Message'])
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Could not update counter'})
        }
